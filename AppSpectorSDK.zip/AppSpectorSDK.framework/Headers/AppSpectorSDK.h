//
//  AppSpectorSDK.h
//  AppSpectorSDK
//
//  Created by Techery on 5/10/17.
//  Copyright © 2017 Techery. All rights reserved.
//

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double AppSpectorSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char AppSpectorSDKVersionString[];

#import <AppSpectorSDK/AppSpector.h>
