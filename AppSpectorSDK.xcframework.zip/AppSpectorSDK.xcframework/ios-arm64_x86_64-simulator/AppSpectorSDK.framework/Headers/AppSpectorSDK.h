//
//  AppSpectorSDK.h
//  AppSpectorSDK
//
//  Created by Techery on 5/10/17.
//  Copyright © 2017 Techery. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AppSpectorSDK/AppSpector.h>
